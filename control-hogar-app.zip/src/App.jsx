import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Home, Wallet, ListChecks, PieChart as PieIcon, Settings as SettingsIcon,
  Plus, X, Check, Paperclip, Trash2, Pencil, Copy, ChevronLeft, ChevronRight,
  Camera, Image as ImageIcon, AlertTriangle, Search, Download, Upload,
  RotateCcw, PiggyBank, ChevronDown, Wallet2, Landmark, Lock, Unlock
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";
import { storageGet, storageSet, storageDelete, storageListPrefix, subscribeKey } from "./storage";

/* ============================================================
   CONSTANTS
============================================================ */
const MONTHS = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
const MONTHS_SHORT = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];
const RESPONSIBLES = ["Susan","Ale","Ambos","Hogar"];
const INCOME_PERSONS = ["Susan","Ale","Hogar"];
const INCOME_TYPES = ["Salario","Ingreso extra","Otro"];
const PIE_COLORS = ["#123C4A","#2E8B8B","#4CAF7D","#E2A63B","#E36767","#7C5CBF","#3A7CA5","#B5895A","#5A8F69","#C97B84","#8B6F47","#6B7686","#D98E5B"];

/* ============================================================
   HELPERS
============================================================ */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

function formatCRC(n) {
  const v = Math.round(Number(n) || 0);
  return "₡" + v.toLocaleString("es-CR");
}
function pad2(n) { return String(n).padStart(2, "0"); }
function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function formatDateShort(iso) {
  if (!iso) return "—";
  const parts = iso.split("-");
  if (parts.length < 3) return "—";
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  if (isNaN(d.getTime())) return "—";
  return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
}
function monthKey(y, m) { return `${y}-${m}`; }

function compressImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const maxW = 900;
        const scale = Math.min(1, maxW / img.width);
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.62));
      };
      img.onerror = () => reject(new Error("No se pudo leer la imagen"));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error("No se pudo leer el archivo"));
    reader.readAsDataURL(file);
  });
}

/* ============================================================
   DEFAULT DATA
============================================================ */
function defaultCategories() {
  return [
    { id: "vivienda", name: "Vivienda" },
    { id: "servicios", name: "Servicios" },
    { id: "telefonia", name: "Telefonía / Internet" },
    { id: "alimentacion", name: "Alimentación" },
    { id: "transporte", name: "Transporte" },
    { id: "educacion", name: "Educación / Cuido" },
    { id: "deudas", name: "Deudas", isDebt: true },
    { id: "tarjetas", name: "Tarjetas", isDebt: true },
    { id: "salud", name: "Salud" },
    { id: "mascotas", name: "Mascotas" },
    { id: "ocio", name: "Ocio" },
    { id: "ahorro", name: "Ahorro" },
    { id: "otros", name: "Otros" },
  ];
}
function defaultRecurring() {
  return [
    { id: uid(), name: "Luz casa", categoryId: "servicios", budgeted: 45000, responsible: "Ambos", quincena: 15, dueDay: 10, active: true },
    { id: uid(), name: "Luz negocio", categoryId: "servicios", budgeted: 35000, responsible: "Hogar", quincena: 15, dueDay: 10, active: true },
    { id: uid(), name: "Agua", categoryId: "servicios", budgeted: 12000, responsible: "Ambos", quincena: 30, dueDay: 25, active: true },
    { id: uid(), name: "Kolbi", categoryId: "telefonia", budgeted: 25000, responsible: "Ambos", quincena: 15, dueDay: 5, active: true },
    { id: uid(), name: "Celular Ale", categoryId: "telefonia", budgeted: 15000, responsible: "Ale", quincena: 15, dueDay: 5, active: true },
    { id: uid(), name: "Celular Susan", categoryId: "telefonia", budgeted: 15000, responsible: "Susan", quincena: 15, dueDay: 5, active: true },
    { id: uid(), name: "Celular Santi", categoryId: "telefonia", budgeted: 10000, responsible: "Ambos", quincena: 15, dueDay: 5, active: true },
    { id: uid(), name: "Cuido", categoryId: "educacion", budgeted: 120000, responsible: "Ambos", quincena: 15, dueDay: 5, active: true },
    { id: uid(), name: "Comida", categoryId: "alimentacion", budgeted: 150000, responsible: "Ambos", quincena: 30, dueDay: 28, active: true },
    { id: uid(), name: "Carnes", categoryId: "alimentacion", budgeted: 60000, responsible: "Ambos", quincena: 30, dueDay: 28, active: true },
    { id: uid(), name: "Verduras", categoryId: "alimentacion", budgeted: 30000, responsible: "Ambos", quincena: 30, dueDay: 28, active: true },
    { id: uid(), name: "Alquiler", categoryId: "vivienda", budgeted: 350000, responsible: "Ambos", quincena: 15, dueDay: 5, active: true },
    { id: uid(), name: "Abogado", categoryId: "otros", budgeted: 20000, responsible: "Hogar", quincena: 30, dueDay: 20, active: true },
    { id: uid(), name: "Tarjetas", categoryId: "tarjetas", budgeted: 80000, responsible: "Ambos", quincena: 30, dueDay: 20, active: true },
    { id: uid(), name: "Deudas / Cooperativas", categoryId: "deudas", budgeted: 60000, responsible: "Ambos", quincena: 30, dueDay: 20, active: true },
  ];
}
function defaultFunds() {
  return [
    { id: uid(), name: "Marchamo", goal: 300000, balance: 0, monthlyContribution: 25000 },
    { id: uid(), name: "Regalos", goal: 0, balance: 0, monthlyContribution: 0 },
    { id: uid(), name: "Escuela", goal: 0, balance: 0, monthlyContribution: 0 },
    { id: uid(), name: "Reparaciones", goal: 0, balance: 0, monthlyContribution: 0 },
    { id: uid(), name: "Vacaciones", goal: 0, balance: 0, monthlyContribution: 0 },
    { id: uid(), name: "Emergencias", goal: 0, balance: 0, monthlyContribution: 0 },
  ];
}
function makeEmptyData() {
  return {
    categories: defaultCategories(),
    recurringTemplates: defaultRecurring(),
    funds: defaultFunds(),
    fundMovements: [],
    debts: [],
    settings: { receiptsMode: "recommended", demoLoaded: false },
    months: {},
  };
}

function buildExpenseFromTemplate(t, y, m) {
  let dueDate = null;
  if (t.dueDay) {
    const dd = Math.min(Number(t.dueDay), 28);
    dueDate = `${y}-${pad2(m)}-${pad2(dd)}`;
  }
  return {
    id: uid(), name: t.name, categoryId: t.categoryId, budgeted: Number(t.budgeted) || 0,
    actual: null, responsible: t.responsible, quincena: t.quincena, dueDate,
    plannedDate: null, paidDate: null, status: "Pendiente", recurring: true,
    templateId: t.id, note: "", hasReceipt: false,
  };
}
function ensureMonth(data, y, m) {
  const key = monthKey(y, m);
  if (data.months[key]) return data;
  const expenses = data.recurringTemplates.filter(t => t.active).map(t => buildExpenseFromTemplate(t, y, m));
  return {
    ...data,
    months: {
      ...data.months,
      [key]: { year: y, month: m, income: [], expenses, savings: [], initialBalance: 0, initialBalanceEnabled: false, closed: false },
    },
  };
}
function seedDemoData(data) {
  const now = new Date();
  const y = now.getFullYear(), m = now.getMonth() + 1;
  let d = ensureMonth(data, y, m);
  const key = monthKey(y, m);
  let month = { ...d.months[key] };
  month.income = [
    { id: uid(), person: "Susan", concept: "Salario", amount: 450000, date: `${y}-${pad2(m)}-15`, quincena: 15, type: "Salario", note: "" },
    { id: uid(), person: "Ale", concept: "Salario", amount: 400000, date: `${y}-${pad2(m)}-15`, quincena: 15, type: "Salario", note: "" },
    { id: uid(), person: "Susan", concept: "Salario", amount: 450000, date: `${y}-${pad2(m)}-30`, quincena: 30, type: "Salario", note: "" },
    { id: uid(), person: "Ale", concept: "Salario", amount: 400000, date: `${y}-${pad2(m)}-30`, quincena: 30, type: "Salario", note: "" },
    { id: uid(), person: "Hogar", concept: "Reembolso seguro", amount: 20000, date: `${y}-${pad2(m)}-18`, quincena: 15, type: "Ingreso extra", note: "" },
  ];
  month.expenses = month.expenses.map(e => {
    if (e.name === "Luz casa") return { ...e, status: "Pagado", actual: Number(e.budgeted) + 3500, paidDate: `${y}-${pad2(m)}-08` };
    if (e.name === "Kolbi") return { ...e, status: "Pagado", actual: e.budgeted, paidDate: `${y}-${pad2(m)}-05` };
    if (e.name === "Alquiler") return { ...e, status: "Pagado", actual: e.budgeted, paidDate: `${y}-${pad2(m)}-03` };
    if (e.name === "Celular Ale") return { ...e, status: "Pagado", actual: e.budgeted, paidDate: `${y}-${pad2(m)}-05` };
    return e;
  });
  d = { ...d, months: { ...d.months, [key]: month }, settings: { ...d.settings, demoLoaded: true } };
  d.debts = [{ id: uid(), name: "Tarjeta BAC", monthlyPayment: 45000, balance: 620000 }];
  return d;
}

/* ============================================================
   CALCULATIONS
============================================================ */
function actualAmount(e) { return e.status === "Pagado" ? (e.actual !== null && e.actual !== "" && e.actual !== undefined ? Number(e.actual) : Number(e.budgeted) || 0) : 0; }
function pendingAmount(e) { return e.status === "Pendiente" ? (Number(e.budgeted) || 0) : 0; }
function committedAmount(e) { return e.status === "Pagado" ? actualAmount(e) : pendingAmount(e); }
function isOverdue(e) { return e.status === "Pendiente" && e.dueDate && e.dueDate < todayISO(); }

function calcMonthTotals(month) {
  const income = month?.income || [];
  const expenses = month?.expenses || [];
  const totalIncome = income.reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const paid = expenses.reduce((s, e) => s + actualAmount(e), 0);
  const pending = expenses.reduce((s, e) => s + pendingAmount(e), 0);
  const committed = paid + pending;
  const initial = month?.initialBalanceEnabled ? (Number(month.initialBalance) || 0) : 0;
  const free = initial + totalIncome - committed;
  const bySusanIncome = income.filter(i => i.person === "Susan").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const byAleIncome = income.filter(i => i.person === "Ale").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const extrasIncome = income.filter(i => i.person === "Hogar").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const paidBySusan = expenses.filter(e => e.status === "Pagado" && e.responsible === "Susan").reduce((s, e) => s + actualAmount(e), 0);
  const paidByAle = expenses.filter(e => e.status === "Pagado" && e.responsible === "Ale").reduce((s, e) => s + actualAmount(e), 0);
  const paidByAmbos = expenses.filter(e => e.status === "Pagado" && (e.responsible === "Ambos" || e.responsible === "Hogar")).reduce((s, e) => s + actualAmount(e), 0);
  const savings = (month?.savings || []).reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const budgetedOfPaid = expenses.filter(e => e.status === "Pagado").reduce((s, e) => s + (Number(e.budgeted) || 0), 0);
  const actualPaid = paid;
  const pct = totalIncome > 0 ? (committed / totalIncome) * 100 : 0;
  return { totalIncome, paid, pending, committed, free, bySusanIncome, byAleIncome, extrasIncome, paidBySusan, paidByAle, paidByAmbos, initial, savings, budgetedOfPaid, actualPaid, pct };
}
function calcQuincena(month, q) {
  const income = (month?.income || []).filter(i => i.quincena === q);
  const expenses = (month?.expenses || []).filter(e => e.quincena === q);
  const susan = income.filter(i => i.person === "Susan").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const ale = income.filter(i => i.person === "Ale").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const extras = income.filter(i => i.person === "Hogar").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const gastos = expenses.reduce((s, e) => s + committedAmount(e), 0);
  const libre = susan + ale + extras - gastos;
  return { susan, ale, extras, gastos, libre };
}
function semaforo(pct) {
  if (pct <= 70) return { emoji: "🟢", label: "Cómodo", color: "var(--green)" };
  if (pct <= 90) return { emoji: "🟡", label: "Ajustado", color: "var(--amber)" };
  return { emoji: "🔴", label: "Muy comprometido", color: "var(--rose)" };
}

/* ============================================================
   SMALL UI PRIMITIVES
============================================================ */
function Card({ children, className = "", style = {} }) {
  return <div className={`chc-card p-4 ${className}`} style={style}>{children}</div>;
}
function Pill({ tone = "neutral", children }) {
  const cls = tone === "green" ? "chc-pill-green" : tone === "amber" ? "chc-pill-amber" : tone === "rose" ? "chc-pill-rose" : "chc-pill-neutral";
  return <span className={`chc-pill ${cls}`}>{children}</span>;
}
function BigButton({ children, onClick, variant = "primary", className = "", type = "button", disabled }) {
  const cls = variant === "primary" ? "chc-btn-primary" : variant === "ghost" ? "chc-btn-ghost" : variant === "danger" ? "chc-btn-danger" : "chc-btn-soft";
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={`chc-btn ${cls} ${className}`}>
      {children}
    </button>
  );
}
function Field({ label, children, hint }) {
  return (
    <label className="block mb-3">
      <span className="block text-sm font-medium mb-1" style={{ color: "var(--muted)" }}>{label}</span>
      {children}
      {hint ? <span className="block text-xs mt-1" style={{ color: "var(--muted)" }}>{hint}</span> : null}
    </label>
  );
}
function TextInput(props) {
  return <input {...props} className={`chc-input ${props.className || ""}`} />;
}
function SelectInput({ children, ...props }) {
  return <select {...props} className={`chc-input ${props.className || ""}`}>{children}</select>;
}
function Modal({ open, onClose, title, children, wide }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" style={{ background: "rgba(18,26,33,0.45)" }} onClick={onClose}>
      <div
        className={`chc-card w-full ${wide ? "sm:max-w-lg" : "sm:max-w-md"} sm:rounded-3xl rounded-t-3xl max-h-[92vh] overflow-y-auto p-5`}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-bold" style={{ color: "var(--petrol)" }}>{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-full" style={{ background: "var(--bg)" }}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
function ConfirmModal({ state, onClose }) {
  if (!state?.open) return null;
  return (
    <Modal open={state.open} onClose={onClose} title={state.title || "Confirmar"}>
      <p className="text-sm mb-4" style={{ color: "var(--ink)" }}>{state.message}</p>
      {state.warning ? (
        <div className="flex items-start gap-2 mb-4 p-3 rounded-2xl" style={{ background: "var(--amber-bg)" }}>
          <AlertTriangle size={16} className="mt-0.5" style={{ color: "#95610f" }} />
          <span className="text-sm" style={{ color: "#95610f" }}>{state.warning}</span>
        </div>
      ) : null}
      <div className="flex gap-2">
        <BigButton variant="ghost" className="flex-1" onClick={onClose}>Cancelar</BigButton>
        <BigButton variant={state.danger ? "danger" : "primary"} className="flex-1" onClick={() => { state.onConfirm && state.onConfirm(); onClose(); }}>
          {state.confirmLabel || "Confirmar"}
        </BigButton>
      </div>
    </Modal>
  );
}
function EmptyState({ text, actionLabel, onAction }) {
  return (
    <Card className="text-center py-8">
      <p className="text-sm mb-3" style={{ color: "var(--muted)" }}>{text}</p>
      {actionLabel ? <BigButton onClick={onAction}><Plus size={16} className="inline -mt-0.5 mr-1" />{actionLabel}</BigButton> : null}
    </Card>
  );
}
function StatusPill({ e }) {
  if (e.status === "Pagado") return <Pill tone="green"><Check size={12} className="inline -mt-0.5 mr-0.5" />Pagado</Pill>;
  if (isOverdue(e)) return <Pill tone="rose">Vencido</Pill>;
  return <Pill tone="amber">Pendiente</Pill>;
}

/* ============================================================
   ROOT APP
============================================================ */
export default function App() {
  const [data, setDataRaw] = useState(null);
  const [loading, setLoading] = useState(true);
  const saveTimer = useRef(null);

  const now = new Date();
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [tab, setTab] = useState("inicio");

  const [incomeModal, setIncomeModal] = useState({ open: false, editing: null, prefill: null });
  const [expenseModal, setExpenseModal] = useState({ open: false, editing: null });
  const [paymentModal, setPaymentModal] = useState({ open: false, expense: null });
  const [receiptModal, setReceiptModal] = useState({ open: false, expenseId: null, src: null });
  const [confirmModal, setConfirmModal] = useState({ open: false });
  const [closeMonthModal, setCloseMonthModal] = useState(false);

  useEffect(() => {
    // Realtime shared subscription: whenever either phone writes, both update live.
    const unsubscribe = subscribeKey("appdata", (raw) => {
      if (raw) {
        try { setDataRaw(JSON.parse(raw)); } catch (e) { /* ignore malformed */ }
        setLoading(false);
      } else {
        (async () => {
          const seeded = seedDemoData(makeEmptyData());
          await storageSet("appdata", JSON.stringify(seeded));
        })();
      }
    });
    return () => unsubscribe && unsubscribe();
  }, []);

  function setData(updater) {
    setDataRaw(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => { storageSet("appdata", JSON.stringify(next)); }, 350);
      return next;
    });
  }

  useEffect(() => {
    if (!data) return;
    const key = monthKey(selectedYear, selectedMonth);
    if (!data.months[key]) setData(d => ensureMonth(d, selectedYear, selectedMonth));
  }, [data, selectedYear, selectedMonth]);

  if (loading || !data) {
    return (
      <div className="chc-app flex items-center justify-center" style={{ minHeight: "100vh" }}>
        <ChcStyle />
        <div className="text-center">
          <div className="chc-spinner mx-auto mb-3" />
          <p style={{ color: "var(--muted)" }}>Cargando Control Hogar…</p>
        </div>
      </div>
    );
  }

  const key = monthKey(selectedYear, selectedMonth);
  const month = data.months[key] || { year: selectedYear, month: selectedMonth, income: [], expenses: [], savings: [], initialBalance: 0, initialBalanceEnabled: false, closed: false };

  /* ---------- generic month updater ---------- */
  function updateMonth(updater) {
    setData(d => {
      const k = monthKey(selectedYear, selectedMonth);
      const base = d.months[k] || { year: selectedYear, month: selectedMonth, income: [], expenses: [], savings: [], initialBalance: 0, initialBalanceEnabled: false, closed: false };
      return { ...d, months: { ...d.months, [k]: updater(base) } };
    });
  }

  /* ---------- income ---------- */
  function addIncome(entry) { updateMonth(m => ({ ...m, income: [...m.income, { ...entry, id: uid() }] })); }
  function updateIncome(id, patch) { updateMonth(m => ({ ...m, income: m.income.map(i => i.id === id ? { ...i, ...patch } : i) })); }
  function deleteIncome(id) { updateMonth(m => ({ ...m, income: m.income.filter(i => i.id !== id) })); }

  /* ---------- expenses ---------- */
  function addExpense(entry) { updateMonth(m => ({ ...m, expenses: [...m.expenses, { id: uid(), actual: null, paidDate: null, status: "Pendiente", hasReceipt: false, recurring: false, templateId: null, note: "", ...entry }] })); }
  function updateExpense(id, patch) { updateMonth(m => ({ ...m, expenses: m.expenses.map(e => e.id === id ? { ...e, ...patch } : e) })); }
  function deleteExpense(id) { updateMonth(m => ({ ...m, expenses: m.expenses.filter(e => e.id !== id) })); }
  function duplicateExpense(id) {
    updateMonth(m => {
      const e = m.expenses.find(x => x.id === id);
      if (!e) return m;
      const copy = { ...e, id: uid(), status: "Pendiente", actual: null, paidDate: null, hasReceipt: false, name: e.name + " (copia)" };
      return { ...m, expenses: [...m.expenses, copy] };
    });
  }
  function markPaid(id, opts) {
    updateMonth(m => ({
      ...m, expenses: m.expenses.map(e => e.id === id ? {
        ...e, status: "Pagado",
        actual: opts.actual !== "" && opts.actual !== null && opts.actual !== undefined ? Number(opts.actual) : Number(e.budgeted) || 0,
        paidDate: opts.paidDate || todayISO(),
        note: opts.note !== undefined ? opts.note : e.note,
      } : e)
    }));
  }
  function markPending(id) { updateMonth(m => ({ ...m, expenses: m.expenses.map(e => e.id === id ? { ...e, status: "Pendiente", paidDate: null } : e) })); }

  async function attachReceipt(expenseId, file) {
    try {
      const dataUrl = await compressImage(file);
      await storageSet("receipt-" + expenseId, dataUrl);
      updateMonth(m => ({ ...m, expenses: m.expenses.map(e => e.id === expenseId ? { ...e, hasReceipt: true } : e) }));
    } catch (err) { /* ignore silently, keep UX simple */ }
  }
  async function removeReceipt(expenseId) {
    await storageDelete("receipt-" + expenseId);
    updateMonth(m => ({ ...m, expenses: m.expenses.map(e => e.id === expenseId ? { ...e, hasReceipt: false } : e) }));
    setReceiptModal({ open: false, expenseId: null, src: null });
  }
  async function viewReceipt(expenseId) {
    const val = await storageGet("receipt-" + expenseId);
    if (val) setReceiptModal({ open: true, expenseId, src: val });
  }

  /* ---------- savings ---------- */
  function addSaving(entry) { updateMonth(m => ({ ...m, savings: [...m.savings, { ...entry, id: uid() }] })); }
  function deleteSaving(id) { updateMonth(m => ({ ...m, savings: m.savings.filter(s => s.id !== id) })); }

  /* ---------- initial balance ---------- */
  function setInitialBalance(value, enabled) { updateMonth(m => ({ ...m, initialBalance: Number(value) || 0, initialBalanceEnabled: enabled })); }

  /* ---------- close / reopen ---------- */
  function closeMonth() { updateMonth(m => ({ ...m, closed: true })); }
  function reopenMonth() { updateMonth(m => ({ ...m, closed: false })); }

  /* ---------- categories ---------- */
  function addCategory(name) { setData(d => ({ ...d, categories: [...d.categories, { id: uid(), name }] })); }
  function updateCategory(id, name) { setData(d => ({ ...d, categories: d.categories.map(c => c.id === id ? { ...c, name } : c) })); }
  function deleteCategory(id) { setData(d => ({ ...d, categories: d.categories.filter(c => c.id !== id) })); }

  /* ---------- recurring templates ---------- */
  function addRecurringTemplate(t) { setData(d => ({ ...d, recurringTemplates: [...d.recurringTemplates, t] })); }
  function updateRecurringTemplate(id, patch) { setData(d => ({ ...d, recurringTemplates: d.recurringTemplates.map(t => t.id === id ? { ...t, ...patch } : t) })); }
  function deleteRecurringTemplate(id) { setData(d => ({ ...d, recurringTemplates: d.recurringTemplates.filter(t => t.id !== id) })); }

  /* ---------- funds ---------- */
  function addFund(fund) { setData(d => ({ ...d, funds: [...d.funds, { id: uid(), balance: 0, goal: 0, monthlyContribution: 0, ...fund }] })); }
  function updateFund(id, patch) { setData(d => ({ ...d, funds: d.funds.map(f => f.id === id ? { ...f, ...patch } : f) })); }
  function deleteFund(id) { setData(d => ({ ...d, funds: d.funds.filter(f => f.id !== id) })); }
  function addFundMovement(fundId, type, amount, dateVal, note) {
    setData(d => {
      const amt = Number(amount) || 0;
      const funds = d.funds.map(f => f.id === fundId ? { ...f, balance: type === "aporte" ? f.balance + amt : Math.max(0, f.balance - amt) } : f);
      const fundMovements = [...d.fundMovements, { id: uid(), fundId, type, amount: amt, date: dateVal || todayISO(), note: note || "" }];
      return { ...d, funds, fundMovements };
    });
  }

  /* ---------- debts ---------- */
  function addDebt(debt) { setData(d => ({ ...d, debts: [...d.debts, { id: uid(), ...debt }] })); }
  function updateDebt(id, patch) { setData(d => ({ ...d, debts: d.debts.map(x => x.id === id ? { ...x, ...patch } : x) })); }
  function deleteDebt(id) { setData(d => ({ ...d, debts: d.debts.filter(x => x.id !== id) })); }

  /* ---------- settings ---------- */
  function setReceiptsMode(mode) { setData(d => ({ ...d, settings: { ...d.settings, receiptsMode: mode } })); }

  /* ---------- backup / export / reset ---------- */
  function exportBackup() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `control-hogar-respaldo-${todayISO()}.json`; a.click();
    URL.revokeObjectURL(url);
  }
  function importBackup(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target.result);
        if (!parsed.months || !parsed.categories) { alert("El archivo no tiene el formato esperado de Control Hogar."); return; }
        setConfirmModal({
          open: true, title: "Importar respaldo",
          message: "Esto reemplazará todos los datos actuales de la aplicación con el contenido del archivo. Esta acción no se puede deshacer.",
          confirmLabel: "Importar y reemplazar", danger: true,
          onConfirm: () => { setDataRaw(parsed); storageSet("appdata", JSON.stringify(parsed)); },
        });
      } catch (err) { alert("No se pudo leer el archivo. Verifica que sea un respaldo válido de Control Hogar."); }
    };
    reader.readAsText(file);
  }
  function exportCSV() {
    const rows = [["Tipo", "Nombre/Concepto", "Categoria/Persona", "Quincena", "Presupuestado/Monto", "Real", "Estado", "Fecha"]];
    month.income.forEach(i => rows.push(["Ingreso", i.concept, i.person, i.quincena, i.amount, "", "", i.date || ""]));
    month.expenses.forEach(e => rows.push(["Gasto", e.name, cat(e.categoryId), e.quincena, e.budgeted, e.actual ?? "", e.status, e.paidDate || e.dueDate || ""]));
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `control-hogar-${MONTHS[selectedMonth - 1]}-${selectedYear}.csv`; a.click();
    URL.revokeObjectURL(url);
  }
  async function resetApp() {
    await storageDelete("appdata");
    const receiptKeys = await storageListPrefix("receipt-");
    for (const k of receiptKeys) await storageDelete(k);
    const fresh = makeEmptyData();
    setDataRaw(fresh);
    await storageSet("appdata", JSON.stringify(fresh));
    setSelectedYear(now.getFullYear()); setSelectedMonth(now.getMonth() + 1); setTab("inicio");
  }
  async function removeDemoData() {
    const receiptKeys = await storageListPrefix("receipt-");
    for (const k of receiptKeys) await storageDelete(k);
    setData(d => ({ ...d, months: {} }));
  }

  function cat(id) { return data.categories.find(c => c.id === id)?.name || "Otros"; }
  function isDebtCategory(id) { return !!data.categories.find(c => c.id === id)?.isDebt; }

  const totals = calcMonthTotals(month);
  const q15 = calcQuincena(month, 15);
  const q30 = calcQuincena(month, 30);
  const sem = semaforo(totals.pct);

  const ctx = {
    data, month, selectedYear, selectedMonth, setSelectedYear, setSelectedMonth,
    totals, q15, q30, sem, cat, isDebtCategory,
    addIncome, updateIncome, deleteIncome,
    addExpense, updateExpense, deleteExpense, duplicateExpense, markPaid, markPending,
    attachReceipt, removeReceipt, viewReceipt,
    addSaving, deleteSaving, setInitialBalance, closeMonth, reopenMonth,
    addCategory, updateCategory, deleteCategory,
    addRecurringTemplate, updateRecurringTemplate, deleteRecurringTemplate,
    addFund, updateFund, deleteFund, addFundMovement,
    addDebt, updateDebt, deleteDebt,
    setReceiptsMode, exportBackup, importBackup, exportCSV, resetApp, removeDemoData,
    setIncomeModal, setExpenseModal, setPaymentModal, setReceiptModal, setConfirmModal, setCloseMonthModal,
  };

  return (
    <div className="chc-app">
      <ChcStyle />
      <TopHeader ctx={ctx} setTab={setTab} />
      <main className="max-w-3xl mx-auto px-3 pb-28 md:pb-10 md:pl-60 pt-3">
        {tab === "inicio" && <Dashboard ctx={ctx} setTab={setTab} />}
        {tab === "ingresos" && <IncomeView ctx={ctx} />}
        {tab === "gastos" && <ExpensesView ctx={ctx} />}
        {tab === "resumen" && <SummaryView ctx={ctx} />}
        {tab === "config" && <SettingsView ctx={ctx} />}
      </main>
      <SideNav tab={tab} setTab={setTab} />
      <BottomNav tab={tab} setTab={setTab} />

      <IncomeModal state={incomeModal} onClose={() => setIncomeModal({ open: false, editing: null, prefill: null })} ctx={ctx} />
      <ExpenseModal state={expenseModal} onClose={() => setExpenseModal({ open: false, editing: null })} ctx={ctx} />
      <PaymentModal state={paymentModal} onClose={() => setPaymentModal({ open: false, expense: null })} ctx={ctx} />
      <ReceiptModal state={receiptModal} onClose={() => setReceiptModal({ open: false, expenseId: null, src: null })} ctx={ctx} />
      <ConfirmModal state={confirmModal} onClose={() => setConfirmModal({ open: false })} />
      <CloseMonthModal open={closeMonthModal} onClose={() => setCloseMonthModal(false)} ctx={ctx} />
    </div>
  );
}

/* ============================================================
   HEADER / NAV
============================================================ */
function TopHeader({ ctx, setTab }) {
  const { selectedYear, selectedMonth, setSelectedYear, setSelectedMonth, month, setIncomeModal, setExpenseModal } = ctx;
  function prevMonth() {
    if (selectedMonth === 1) { setSelectedMonth(12); setSelectedYear(selectedYear - 1); }
    else setSelectedMonth(selectedMonth - 1);
  }
  function nextMonth() {
    if (selectedMonth === 12) { setSelectedMonth(1); setSelectedYear(selectedYear + 1); }
    else setSelectedMonth(selectedMonth + 1);
  }
  const years = [];
  for (let y = new Date().getFullYear() - 2; y <= new Date().getFullYear() + 5; y++) years.push(y);
  return (
    <header className="sticky top-0 z-30 md:pl-60" style={{ background: "var(--bg)", borderBottom: "1px solid var(--border)" }}>
      <div className="max-w-3xl mx-auto px-3 pt-3 pb-2 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold tracking-tight" style={{ color: "var(--petrol)" }}>Control Hogar</h1>
          {month.closed ? (
            <span className="inline-flex items-center gap-1 text-xs font-semibold" style={{ color: "var(--muted)" }}><Lock size={11} /> Mes cerrado</span>
          ) : null}
        </div>
        <div className="flex gap-2">
          <button onClick={() => setIncomeModal({ open: true, editing: null, prefill: null })} className="chc-quickbtn" style={{ background: "var(--green-bg)", color: "#1f7a4d" }}>
            <Plus size={14} /> Ingreso
          </button>
          <button onClick={() => setExpenseModal({ open: true, editing: null })} className="chc-quickbtn" style={{ background: "var(--rose-bg)", color: "#b23a3a" }}>
            <Plus size={14} /> Gasto
          </button>
        </div>
      </div>
      <div className="max-w-3xl mx-auto px-3 pb-3 flex items-center justify-center gap-2">
        <button onClick={prevMonth} className="chc-iconbtn"><ChevronLeft size={18} /></button>
        <select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="chc-input chc-select-inline">
          {MONTHS.map((mo, i) => <option key={mo} value={i + 1}>{mo}</option>)}
        </select>
        <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="chc-input chc-select-inline" style={{ width: 90 }}>
          {years.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
        <button onClick={nextMonth} className="chc-iconbtn"><ChevronRight size={18} /></button>
      </div>
    </header>
  );
}

const NAV_ITEMS = [
  { id: "inicio", label: "Inicio", icon: Home },
  { id: "ingresos", label: "Ingresos", icon: Wallet },
  { id: "gastos", label: "Gastos", icon: ListChecks },
  { id: "resumen", label: "Resumen", icon: PieIcon },
  { id: "config", label: "Ajustes", icon: SettingsIcon },
];
function BottomNav({ tab, setTab }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 md:hidden" style={{ background: "var(--card)", borderTop: "1px solid var(--border)" }}>
      <div className="flex justify-around py-1.5">
        {NAV_ITEMS.map(it => {
          const Icon = it.icon;
          const active = tab === it.id;
          return (
            <button key={it.id} onClick={() => setTab(it.id)} className="flex flex-col items-center gap-0.5 px-2 py-1 chc-nav-item" style={{ color: active ? "var(--petrol)" : "var(--muted)" }}>
              <Icon size={22} strokeWidth={active ? 2.4 : 2} />
              <span className="text-[11px] font-medium">{it.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
function SideNav({ tab, setTab }) {
  return (
    <nav className="hidden md:flex md:flex-col fixed left-0 top-0 bottom-0 w-56 p-4 pt-6 gap-1 z-30" style={{ background: "var(--card)", borderRight: "1px solid var(--border)" }}>
      <h2 className="text-xl font-extrabold mb-4 px-2" style={{ color: "var(--petrol)" }}>Control Hogar</h2>
      {NAV_ITEMS.map(it => {
        const Icon = it.icon;
        const active = tab === it.id;
        return (
          <button key={it.id} onClick={() => setTab(it.id)} className="flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-semibold" style={{ background: active ? "var(--petrol)" : "transparent", color: active ? "#fff" : "var(--ink)" }}>
            <Icon size={18} /> {it.label}
          </button>
        );
      })}
    </nav>
  );
}

/* ============================================================
   DASHBOARD
============================================================ */
function Dashboard({ ctx, setTab }) {
  const { totals, q15, q30, sem, month, cat, setPaymentModal, setExpenseModal } = ctx;
  const upcoming = useMemo(() => {
    return [...month.expenses]
      .filter(e => e.status === "Pendiente")
      .sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      })
      .slice(0, 5);
  }, [month]);

  return (
    <div className="space-y-4">
      <div className="chc-hero p-5">
        <p className="text-sm opacity-90 mb-1">Dinero libre</p>
        <p className="chc-num text-4xl font-extrabold">{formatCRC(totals.free)}</p>
        <p className="text-xs opacity-80 mt-1">Después de gastos pagados y comprometidos</p>
        <div className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: "rgba(255,255,255,0.18)" }}>
          <span>{sem.emoji}</span><span>{sem.label} · {totals.pct.toFixed(0)}% comprometido</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <MiniStat label="Ingresó" value={totals.totalIncome} tone="green" />
        <MiniStat label="Comprometido" value={totals.committed} tone="amber" />
        <MiniStat label="Pagado" value={totals.paid} tone="green" />
        <MiniStat label="Pendiente" value={totals.pending} tone="rose" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <QuincenaCard title="Quincena 15" data={q15} />
        <QuincenaCard title="Quincena 30" data={q30} />
      </div>

      <div>
        <div className="flex items-center justify-between mb-2 px-1">
          <h3 className="font-bold" style={{ color: "var(--petrol)" }}>Próximos pagos</h3>
          <button className="text-sm font-semibold" style={{ color: "var(--teal-accent)" }} onClick={() => setTab("gastos")}>Ver todos</button>
        </div>
        {upcoming.length === 0 ? (
          <Card className="text-center py-6"><p className="text-sm" style={{ color: "var(--muted)" }}>No tienes pagos pendientes. 🎉</p></Card>
        ) : (
          <div className="space-y-2">
            {upcoming.map(e => (
              <Card key={e.id} className="flex items-center justify-between gap-2">
                <div className="min-w-0 flex-1" onClick={() => setExpenseModal({ open: true, editing: e })}>
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold truncate">{e.name}</p>
                    {isOverdue(e) ? <Pill tone="rose">Vencido</Pill> : null}
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: "var(--muted)" }}>{cat(e.categoryId)} · Q{e.quincena} · {e.responsible} · {formatDateShort(e.dueDate)}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="chc-num font-bold mb-1">{formatCRC(e.budgeted)}</p>
                  <button onClick={() => setPaymentModal({ open: true, expense: e })} className="chc-quickbtn" style={{ background: "var(--green-bg)", color: "#1f7a4d" }}>
                    <Check size={13} /> Pagar
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
function MiniStat({ label, value, tone }) {
  const bg = tone === "green" ? "var(--green-bg)" : tone === "amber" ? "var(--amber-bg)" : "var(--rose-bg)";
  const fg = tone === "green" ? "#1f7a4d" : tone === "amber" ? "#95610f" : "#b23a3a";
  return (
    <Card style={{ background: bg }}>
      <p className="text-xs font-semibold mb-1" style={{ color: fg }}>{label}</p>
      <p className="chc-num text-xl font-extrabold" style={{ color: fg }}>{formatCRC(value)}</p>
    </Card>
  );
}
function QuincenaCard({ title, data }) {
  return (
    <Card>
      <p className="font-bold mb-2" style={{ color: "var(--petrol)" }}>{title}</p>
      <div className="space-y-1 text-sm">
        <Row label="Susan" value={data.susan} />
        <Row label="Ale" value={data.ale} />
        <Row label="Extras" value={data.extras} />
        <Row label="Gastos" value={-data.gastos} showAsSpent />
        <div className="border-t my-1.5" style={{ borderColor: "var(--border)" }} />
        <Row label="Libre" value={data.libre} bold />
      </div>
    </Card>
  );
}
function Row({ label, value, bold, showAsSpent }) {
  return (
    <div className="flex justify-between">
      <span style={{ color: bold ? "var(--ink)" : "var(--muted)", fontWeight: bold ? 700 : 500 }}>{label}</span>
      <span className="chc-num" style={{ color: bold ? "var(--petrol)" : "var(--ink)", fontWeight: bold ? 700 : 600 }}>
        {showAsSpent ? "-" + formatCRC(Math.abs(value)) : formatCRC(value)}
      </span>
    </div>
  );
}

/* ============================================================
   INCOME VIEW
============================================================ */
function IncomeView({ ctx }) {
  const { month, deleteIncome, setIncomeModal, selectedMonth, selectedYear } = ctx;
  const [filterQ, setFilterQ] = useState("todos");
  const list = month.income.filter(i => filterQ === "todos" ? true : i.quincena === Number(filterQ));
  const grouped = { 15: list.filter(i => i.quincena === 15), 30: list.filter(i => i.quincena === 30) };

  function quickSalary(person) {
    setIncomeModal({
      open: true, editing: null,
      prefill: { person, concept: "Salario", amount: "", date: `${selectedYear}-${pad2(selectedMonth)}-15`, quincena: 15, type: "Salario", note: "" },
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-1">
        <BigButton onClick={() => quickSalary("Susan")} variant="soft" className="whitespace-nowrap">+ Salario Susan</BigButton>
        <BigButton onClick={() => quickSalary("Ale")} variant="soft" className="whitespace-nowrap">+ Salario Ale</BigButton>
        <BigButton onClick={() => setIncomeModal({ open: true, editing: null, prefill: null })} variant="primary" className="whitespace-nowrap">+ Ingreso</BigButton>
      </div>

      <div className="flex gap-2">
        {["todos", "15", "30"].map(f => (
          <button key={f} onClick={() => setFilterQ(f)} className="chc-filter-chip" style={{ background: filterQ === f ? "var(--petrol)" : "var(--card)", color: filterQ === f ? "#fff" : "var(--ink)", border: filterQ === f ? "none" : "1px solid var(--border)" }}>
            {f === "todos" ? "Todas" : `Quincena ${f}`}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <EmptyState text="Aún no has registrado ingresos." actionLabel="Registrar ingreso" onAction={() => setIncomeModal({ open: true, editing: null, prefill: null })} />
      ) : (
        [15, 30].map(q => grouped[q].length > 0 && (
          <div key={q}>
            <p className="text-sm font-bold mb-2 px-1" style={{ color: "var(--muted)" }}>Quincena {q}</p>
            <div className="space-y-2">
              {grouped[q].map(i => (
                <Card key={i.id} className="flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold truncate">{i.concept || "Ingreso"}</p>
                      <Pill tone={i.person === "Susan" ? "green" : i.person === "Ale" ? "amber" : "neutral"}>{i.person}</Pill>
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: "var(--muted)" }}>{i.type} · {formatDateShort(i.date)}</p>
                  </div>
                  <div className="text-right shrink-0 flex items-center gap-2">
                    <p className="chc-num font-bold" style={{ color: "var(--green)" }}>{formatCRC(i.amount)}</p>
                    <button onClick={() => setIncomeModal({ open: true, editing: i, prefill: null })} className="chc-iconbtn"><Pencil size={14} /></button>
                    <button onClick={() => deleteIncome(i.id)} className="chc-iconbtn"><Trash2 size={14} /></button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

/* ============================================================
   EXPENSES VIEW
============================================================ */
function ExpensesView({ ctx }) {
  const { month, cat, setExpenseModal, setPaymentModal, markPending, duplicateExpense, deleteExpense, viewReceipt, setConfirmModal } = ctx;
  const [filter, setFilter] = useState("todos");
  const [search, setSearch] = useState("");

  let list = [...month.expenses];
  if (filter === "pendientes") list = list.filter(e => e.status === "Pendiente");
  if (filter === "pagados") list = list.filter(e => e.status === "Pagado");
  if (filter === "q15") list = list.filter(e => e.quincena === 15);
  if (filter === "q30") list = list.filter(e => e.quincena === 30);
  if (filter === "susan") list = list.filter(e => e.responsible === "Susan");
  if (filter === "ale") list = list.filter(e => e.responsible === "Ale");
  if (search.trim()) list = list.filter(e => e.name.toLowerCase().includes(search.trim().toLowerCase()));
  list.sort((a, b) => {
    if (a.status !== b.status) return a.status === "Pendiente" ? -1 : 1;
    if (a.status === "Pendiente") return (a.dueDate || "9999") < (b.dueDate || "9999") ? -1 : 1;
    return (b.paidDate || "") < (a.paidDate || "") ? -1 : 1;
  });

  const filters = [
    ["todos", "Todos"], ["pendientes", "Pendientes"], ["pagados", "Pagados"],
    ["q15", "Q15"], ["q30", "Q30"], ["susan", "Susan"], ["ale", "Ale"],
  ];

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="chc-input flex items-center gap-2 flex-1">
          <Search size={16} style={{ color: "var(--muted)" }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar gasto..." className="flex-1 bg-transparent outline-none text-sm" />
        </div>
        <BigButton onClick={() => setExpenseModal({ open: true, editing: null })}><Plus size={16} className="inline -mt-0.5" /></BigButton>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {filters.map(([id, label]) => (
          <button key={id} onClick={() => setFilter(id)} className="chc-filter-chip whitespace-nowrap" style={{ background: filter === id ? "var(--petrol)" : "var(--card)", color: filter === id ? "#fff" : "var(--ink)", border: filter === id ? "none" : "1px solid var(--border)" }}>
            {label}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <EmptyState text="No tienes gastos registrados este mes." actionLabel="Agregar gasto" onAction={() => setExpenseModal({ open: true, editing: null })} />
      ) : (
        <div className="space-y-2">
          {list.map(e => (
            <Card key={e.id}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1" onClick={() => setExpenseModal({ open: true, editing: e })}>
                  <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                    <p className="font-semibold truncate">{e.name}</p>
                    {e.hasReceipt ? <Paperclip size={13} style={{ color: "var(--teal-accent)" }} /> : null}
                    {e.recurring ? <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: "var(--bg)", color: "var(--muted)" }}>RECURRENTE</span> : null}
                  </div>
                  <p className="text-xs" style={{ color: "var(--muted)" }}>{cat(e.categoryId)} · Q{e.quincena} · {e.responsible}</p>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <StatusPill e={e} />
                    <span className="text-xs" style={{ color: "var(--muted)" }}>
                      {e.status === "Pagado" ? `Pagado ${formatDateShort(e.paidDate)}` : `Vence ${formatDateShort(e.dueDate)}`}
                    </span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="chc-num font-bold">{formatCRC(e.status === "Pagado" ? actualAmount(e) : e.budgeted)}</p>
                  {e.status === "Pagado" && e.actual !== null && Number(e.actual) !== Number(e.budgeted) ? (
                    <p className="text-[11px]" style={{ color: "var(--muted)" }}>Presup. {formatCRC(e.budgeted)}</p>
                  ) : null}
                </div>
              </div>
              <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                {e.status === "Pendiente" ? (
                  <button onClick={() => setPaymentModal({ open: true, expense: e })} className="chc-quickbtn" style={{ background: "var(--green-bg)", color: "#1f7a4d" }}><Check size={13} /> Pagar</button>
                ) : (
                  <button onClick={() => markPending(e.id)} className="chc-quickbtn" style={{ background: "var(--amber-bg)", color: "#95610f" }}>Marcar pendiente</button>
                )}
                <button onClick={() => setExpenseModal({ open: true, editing: e })} className="chc-quickbtn" style={{ background: "var(--bg)", color: "var(--ink)" }}><Pencil size={13} /> Editar</button>
                <button onClick={() => duplicateExpense(e.id)} className="chc-quickbtn" style={{ background: "var(--bg)", color: "var(--ink)" }}><Copy size={13} /> Duplicar</button>
                {e.hasReceipt ? (
                  <button onClick={() => viewReceipt(e.id)} className="chc-quickbtn" style={{ background: "var(--bg)", color: "var(--ink)" }}><Paperclip size={13} /> Ver comprobante</button>
                ) : null}
                <button
                  onClick={() => setConfirmModal({ open: true, title: "Eliminar gasto", message: `¿Eliminar "${e.name}"? Esta acción no se puede deshacer.`, danger: true, confirmLabel: "Eliminar", onConfirm: () => deleteExpense(e.id) })}
                  className="chc-quickbtn" style={{ background: "var(--rose-bg)", color: "#b23a3a" }}
                ><Trash2 size={13} /></button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   SUMMARY VIEW
============================================================ */
function SummaryView({ ctx }) {
  const [sub, setSub] = useState("mensual");
  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button onClick={() => setSub("mensual")} className="chc-filter-chip flex-1 text-center" style={{ background: sub === "mensual" ? "var(--petrol)" : "var(--card)", color: sub === "mensual" ? "#fff" : "var(--ink)", border: sub === "mensual" ? "none" : "1px solid var(--border)" }}>Mensual</button>
        <button onClick={() => setSub("anual")} className="chc-filter-chip flex-1 text-center" style={{ background: sub === "anual" ? "var(--petrol)" : "var(--card)", color: sub === "anual" ? "#fff" : "var(--ink)", border: sub === "anual" ? "none" : "1px solid var(--border)" }}>Anual</button>
      </div>
      {sub === "mensual" ? <MonthlySummary ctx={ctx} /> : <AnnualSummary ctx={ctx} />}
    </div>
  );
}

function MonthlySummary({ ctx }) {
  const { totals, sem, month, data, cat, setCloseMonthModal, reopenMonth } = ctx;
  const diff = totals.actualPaid - totals.budgetedOfPaid;
  const debtsTotal = data.debts.reduce((s, d) => s + (Number(d.balance) || 0), 0);
  const fundsTotal = data.funds.reduce((s, f) => s + (Number(f.balance) || 0), 0);
  const pendingCount = month.expenses.filter(e => e.status === "Pendiente").length;

  const pieData = useMemo(() => {
    const byCat = {};
    month.expenses.forEach(e => {
      const amt = committedAmount(e);
      if (amt <= 0) return;
      byCat[e.categoryId] = (byCat[e.categoryId] || 0) + amt;
    });
    return Object.entries(byCat).map(([id, value]) => ({ name: cat(id), value }));
  }, [month, data.categories]);

  const barData = useMemo(() => {
    const arr = [];
    for (let m = 1; m <= 12; m++) {
      const mo = data.months[monthKey(ctx.selectedYear, m)];
      const t = calcMonthTotals(mo || {});
      arr.push({ name: MONTHS_SHORT[m - 1], Ingresos: t.totalIncome, Gastos: t.committed });
    }
    return arr;
  }, [data.months, ctx.selectedYear]);

  return (
    <div className="space-y-4">
      <Card>
        <p className="font-bold mb-3" style={{ color: "var(--petrol)" }}>Resumen del mes</p>
        <div className="space-y-1.5 text-sm">
          <Row label="Ingresos Susan" value={totals.bySusanIncome} />
          <Row label="Ingresos Ale" value={totals.byAleIncome} />
          <Row label="Ingresos extras" value={totals.extrasIncome} />
          <div className="border-t my-1.5" style={{ borderColor: "var(--border)" }} />
          <Row label="Ingreso familiar total" value={totals.totalIncome} bold />
          <div className="border-t my-1.5" style={{ borderColor: "var(--border)" }} />
          <Row label="Pagado" value={totals.paid} />
          <Row label="Pendiente" value={totals.pending} />
          <Row label="Comprometido total" value={totals.committed} bold />
          <div className="border-t my-1.5" style={{ borderColor: "var(--border)" }} />
          <Row label="Dinero libre" value={totals.free} bold />
          <Row label="Ahorro este mes" value={totals.savings} />
          <Row label="Fondos (total acumulado)" value={fundsTotal} />
        </div>
        <div className="mt-3 flex items-center gap-2 text-sm font-semibold px-3 py-2 rounded-2xl" style={{ background: "var(--bg)" }}>
          <span>{sem.emoji}</span><span>{totals.pct.toFixed(0)}% del ingreso está comprometido · {sem.label}</span>
        </div>
      </Card>

      {totals.budgetedOfPaid > 0 && (
        <Card>
          <p className="font-bold mb-2" style={{ color: "var(--petrol)" }}>Presupuesto vs. real (gastos pagados)</p>
          <div className="space-y-1.5 text-sm">
            <Row label="Presupuestado" value={totals.budgetedOfPaid} />
            <Row label="Gasto real" value={totals.actualPaid} />
          </div>
          <p className="text-sm mt-2 font-semibold" style={{ color: diff > 0 ? "var(--rose)" : "var(--green)" }}>
            {diff === 0 ? "Gastaste exactamente lo previsto." : diff > 0 ? `Gastaste ${formatCRC(diff)} más de lo previsto.` : `Gastaste ${formatCRC(Math.abs(diff))} menos de lo previsto.`}
          </p>
        </Card>
      )}

      {debtsTotal > 0 && (
        <Card>
          <p className="font-bold mb-1" style={{ color: "var(--petrol)" }}>Deudas</p>
          <p className="text-sm" style={{ color: "var(--muted)" }}>Saldo total de deudas registradas</p>
          <p className="chc-num text-xl font-extrabold" style={{ color: "var(--rose)" }}>{formatCRC(debtsTotal)}</p>
        </Card>
      )}

      {pieData.length > 0 && (
        <Card>
          <p className="font-bold mb-2" style={{ color: "var(--petrol)" }}>Gastos por categoría</p>
          <div style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                  {pieData.map((entry, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={v => formatCRC(v)} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}

      <Card>
        <p className="font-bold mb-2" style={{ color: "var(--petrol)" }}>Ingresos vs. gastos ({ctx.selectedYear})</p>
        <div style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 10 }} width={40} tickFormatter={v => (v / 1000) + "k"} />
              <Tooltip formatter={v => formatCRC(v)} />
              <Bar dataKey="Ingresos" fill="var(--green)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Gastos" fill="var(--rose)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card>
        {month.closed ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2"><Lock size={16} style={{ color: "var(--muted)" }} /><span className="text-sm font-semibold">Este mes está cerrado.</span></div>
            <BigButton variant="ghost" onClick={reopenMonth}><Unlock size={14} className="inline -mt-0.5 mr-1" />Reabrir mes</BigButton>
          </div>
        ) : (
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="text-sm" style={{ color: "var(--muted)" }}>{pendingCount > 0 ? `Tienes ${pendingCount} gasto(s) pendiente(s).` : "Todos los gastos están al día."}</span>
            <BigButton onClick={() => setCloseMonthModal(true)}><Lock size={14} className="inline -mt-0.5 mr-1" />Cerrar mes</BigButton>
          </div>
        )}
      </Card>
    </div>
  );
}

function AnnualSummary({ ctx }) {
  const { data, selectedYear } = ctx;
  const rows = [];
  for (let m = 1; m <= 12; m++) {
    const mo = data.months[monthKey(selectedYear, m)];
    const t = calcMonthTotals(mo || {});
    rows.push({ m, name: MONTHS[m - 1], ...t });
  }
  const accIncome = rows.reduce((s, r) => s + r.totalIncome, 0);
  const accSpent = rows.reduce((s, r) => s + r.committed, 0);
  const accSaved = rows.reduce((s, r) => s + r.savings, 0);
  const monthsWithData = rows.filter(r => r.totalIncome > 0 || r.committed > 0).length || 1;
  const avgSpent = accSpent / monthsWithData;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <MiniStat label="Ingresos acumulados" value={accIncome} tone="green" />
        <MiniStat label="Gastos acumulados" value={accSpent} tone="rose" />
        <MiniStat label="Ahorro acumulado" value={accSaved} tone="green" />
        <MiniStat label="Promedio mensual gasto" value={avgSpent} tone="amber" />
      </div>
      <div className="space-y-2">
        {rows.map(r => (
          <Card key={r.m}>
            <p className="font-bold mb-1.5">{r.name}</p>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
              <Row label="Ingresos" value={r.totalIncome} />
              <Row label="Gastos" value={r.committed} />
              <Row label="Libre" value={r.free} />
              <Row label="Ahorro" value={r.savings} />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function CloseMonthModal({ open, onClose, ctx }) {
  const { totals, month, closeMonth } = ctx;
  const pendingCount = month.expenses.filter(e => e.status === "Pendiente").length;
  return (
    <Modal open={open} onClose={onClose} title="Cerrar mes">
      <div className="space-y-1.5 text-sm mb-3">
        <Row label="Ingresos" value={totals.totalIncome} />
        <Row label="Pagado" value={totals.paid} />
        <Row label="Pendiente" value={totals.pending} />
        <Row label="Ahorro" value={totals.savings} />
        <Row label="Dinero libre" value={totals.free} bold />
      </div>
      {pendingCount > 0 && (
        <div className="flex items-start gap-2 mb-4 p-3 rounded-2xl" style={{ background: "var(--amber-bg)" }}>
          <AlertTriangle size={16} className="mt-0.5" style={{ color: "#95610f" }} />
          <span className="text-sm" style={{ color: "#95610f" }}>Tienes {pendingCount} gastos pendientes. Puedes cerrar igual; podrás reabrir el mes cuando quieras.</span>
        </div>
      )}
      <BigButton className="w-full" onClick={() => { closeMonth(); onClose(); }}>Confirmar cierre de mes</BigButton>
    </Modal>
  );
}

/* ============================================================
   SETTINGS VIEW
============================================================ */
function SettingsView({ ctx }) {
  const {
    data, setReceiptsMode, addCategory, updateCategory, deleteCategory,
    addRecurringTemplate, updateRecurringTemplate, deleteRecurringTemplate,
    addFund, updateFund, deleteFund, addFundMovement, addDebt, updateDebt, deleteDebt,
    exportBackup, importBackup, exportCSV, resetApp, removeDemoData, setConfirmModal,
    month, setInitialBalance,
  } = ctx;
  const fileInputRef = useRef(null);
  const [newCatName, setNewCatName] = useState("");
  const [resetText, setResetText] = useState("");

  return (
    <div className="space-y-3">
      <Card style={{ background: "var(--amber-bg)" }}>
        <p className="text-sm font-semibold" style={{ color: "#95610f" }}>Datos compartidos</p>
        <p className="text-xs mt-1" style={{ color: "#95610f" }}>
          Esta app usa almacenamiento compartido: cualquier persona que abra este mismo enlace ve y puede editar
          la misma información (sin usuario ni contraseña separados). Compártelo solo con quien deba tener acceso.
        </p>
      </Card>

      <details className="chc-details" open>
        <summary className="chc-summary">Saldo inicial del mes</summary>
        <div className="pt-3">
          <label className="flex items-center gap-2 mb-2 text-sm font-medium">
            <input type="checkbox" checked={month.initialBalanceEnabled} onChange={e => setInitialBalance(month.initialBalance, e.target.checked)} />
            Usar saldo inicial este mes
          </label>
          {month.initialBalanceEnabled && (
            <Field label="Monto del saldo inicial">
              <TextInput type="number" value={month.initialBalance} onChange={e => setInitialBalance(e.target.value, true)} />
            </Field>
          )}
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Comprobantes</summary>
        <div className="pt-3 space-y-2">
          {[["optional", "Opcionales"], ["recommended", "Recomendados"], ["required", "Obligatorios para marcar como pagado"]].map(([id, label]) => (
            <label key={id} className="flex items-center gap-2 text-sm font-medium">
              <input type="radio" checked={data.settings.receiptsMode === id} onChange={() => setReceiptsMode(id)} />
              {label}
            </label>
          ))}
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Categorías</summary>
        <div className="pt-3 space-y-2">
          {data.categories.map(c => (
            <div key={c.id} className="flex items-center gap-2">
              <TextInput value={c.name} onChange={e => updateCategory(c.id, e.target.value)} className="flex-1" />
              <button onClick={() => deleteCategory(c.id)} className="chc-iconbtn"><Trash2 size={14} /></button>
            </div>
          ))}
          <div className="flex items-center gap-2 pt-1">
            <TextInput placeholder="Nueva categoría" value={newCatName} onChange={e => setNewCatName(e.target.value)} className="flex-1" />
            <button onClick={() => { if (newCatName.trim()) { addCategory(newCatName.trim()); setNewCatName(""); } }} className="chc-iconbtn"><Plus size={16} /></button>
          </div>
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Gastos recurrentes</summary>
        <div className="pt-3 space-y-3">
          {data.recurringTemplates.map(t => (
            <RecurringRow key={t.id} t={t} categories={data.categories} onUpdate={p => updateRecurringTemplate(t.id, p)} onDelete={() => deleteRecurringTemplate(t.id)} />
          ))}
          <BigButton variant="soft" className="w-full" onClick={() => addRecurringTemplate({ id: uid(), name: "Nuevo gasto recurrente", categoryId: data.categories[0]?.id, budgeted: 0, responsible: "Ambos", quincena: 15, dueDay: null, active: true })}>
            + Agregar recurrente
          </BigButton>
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Fondos</summary>
        <div className="pt-3 space-y-3">
          {data.funds.map(f => <FundRow key={f.id} f={f} onUpdate={p => updateFund(f.id, p)} onDelete={() => deleteFund(f.id)} onMovement={(type, amount, note) => addFundMovement(f.id, type, amount, todayISO(), note)} />)}
          <BigButton variant="soft" className="w-full" onClick={() => addFund({ id: uid(), name: "Nuevo fondo", goal: 0, balance: 0, monthlyContribution: 0 })}>+ Agregar fondo</BigButton>
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Deudas</summary>
        <div className="pt-3 space-y-3">
          {data.debts.length === 0 ? <p className="text-sm" style={{ color: "var(--muted)" }}>No tienes deudas registradas.</p> : null}
          {data.debts.map(d => <DebtRow key={d.id} d={d} onUpdate={p => updateDebt(d.id, p)} onDelete={() => deleteDebt(d.id)} />)}
          <BigButton variant="soft" className="w-full" onClick={() => addDebt({ id: uid(), name: "Nueva deuda", monthlyPayment: 0, balance: 0 })}>+ Agregar deuda</BigButton>
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Respaldo de datos</summary>
        <div className="pt-3 space-y-2">
          <BigButton className="w-full" onClick={exportBackup}><Download size={15} className="inline -mt-0.5 mr-1" />Exportar respaldo (JSON)</BigButton>
          <BigButton variant="ghost" className="w-full" onClick={() => fileInputRef.current?.click()}><Upload size={15} className="inline -mt-0.5 mr-1" />Importar respaldo</BigButton>
          <input ref={fileInputRef} type="file" accept="application/json" className="hidden" onChange={e => { if (e.target.files[0]) importBackup(e.target.files[0]); e.target.value = ""; }} />
          <BigButton variant="ghost" className="w-full" onClick={exportCSV}><Download size={15} className="inline -mt-0.5 mr-1" />Exportar resumen del mes (CSV)</BigButton>
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary">Datos de demostración</summary>
        <div className="pt-3">
          <BigButton variant="ghost" className="w-full" onClick={() => setConfirmModal({ open: true, title: "Eliminar datos de demostración", message: "Se eliminarán todos los meses cargados (incluidos los de prueba). Las categorías, fondos y recurrentes se conservan.", danger: true, confirmLabel: "Eliminar", onConfirm: removeDemoData })}>
            Eliminar datos de demostración
          </BigButton>
        </div>
      </details>

      <details className="chc-details">
        <summary className="chc-summary" style={{ color: "var(--rose)" }}>Restablecer aplicación</summary>
        <div className="pt-3 space-y-2">
          <p className="text-sm" style={{ color: "var(--muted)" }}>Esto borrará permanentemente todos los datos, incluidos comprobantes. Escribe <strong>BORRAR</strong> para confirmar.</p>
          <TextInput value={resetText} onChange={e => setResetText(e.target.value)} placeholder="BORRAR" />
          <BigButton variant="danger" className="w-full" disabled={resetText !== "BORRAR"} onClick={() => setConfirmModal({ open: true, title: "Restablecer aplicación", message: "Se eliminarán todos los datos de forma permanente.", danger: true, confirmLabel: "Restablecer", onConfirm: () => { resetApp(); setResetText(""); } })}>
            <RotateCcw size={15} className="inline -mt-0.5 mr-1" />Restablecer aplicación
          </BigButton>
        </div>
      </details>
    </div>
  );
}

function RecurringRow({ t, categories, onUpdate, onDelete }) {
  return (
    <div className="p-3 rounded-2xl" style={{ background: "var(--bg)" }}>
      <div className="flex items-center gap-2 mb-2">
        <TextInput value={t.name} onChange={e => onUpdate({ name: e.target.value })} className="flex-1" />
        <label className="flex items-center gap-1 text-xs font-medium shrink-0">
          <input type="checkbox" checked={t.active} onChange={e => onUpdate({ active: e.target.checked })} /> Activo
        </label>
        <button onClick={onDelete} className="chc-iconbtn"><Trash2 size={14} /></button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <SelectInput value={t.categoryId} onChange={e => onUpdate({ categoryId: e.target.value })}>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </SelectInput>
        <SelectInput value={t.responsible} onChange={e => onUpdate({ responsible: e.target.value })}>
          {RESPONSIBLES.map(r => <option key={r} value={r}>{r}</option>)}
        </SelectInput>
        <TextInput type="number" value={t.budgeted} onChange={e => onUpdate({ budgeted: Number(e.target.value) })} placeholder="Monto presupuestado" />
        <SelectInput value={t.quincena} onChange={e => onUpdate({ quincena: Number(e.target.value) })}>
          <option value={15}>Quincena 15</option><option value={30}>Quincena 30</option>
        </SelectInput>
        <TextInput type="number" min="1" max="28" value={t.dueDay || ""} onChange={e => onUpdate({ dueDay: e.target.value ? Number(e.target.value) : null })} placeholder="Día de vencimiento" className="col-span-2" />
      </div>
    </div>
  );
}
function FundRow({ f, onUpdate, onDelete, onMovement }) {
  const [amt, setAmt] = useState("");
  return (
    <div className="p-3 rounded-2xl" style={{ background: "var(--bg)" }}>
      <div className="flex items-center gap-2 mb-2">
        <TextInput value={f.name} onChange={e => onUpdate({ name: e.target.value })} className="flex-1" />
        <button onClick={onDelete} className="chc-iconbtn"><Trash2 size={14} /></button>
      </div>
      <p className="chc-num text-lg font-extrabold mb-2" style={{ color: "var(--petrol)" }}>{formatCRC(f.balance)}</p>
      <div className="flex items-center gap-2">
        <TextInput type="number" placeholder="Monto" value={amt} onChange={e => setAmt(e.target.value)} className="flex-1" />
        <button onClick={() => { if (amt) { onMovement("aporte", amt, ""); setAmt(""); } }} className="chc-quickbtn" style={{ background: "var(--green-bg)", color: "#1f7a4d" }}>+ Aporte</button>
        <button onClick={() => { if (amt) { onMovement("retiro", amt, ""); setAmt(""); } }} className="chc-quickbtn" style={{ background: "var(--rose-bg)", color: "#b23a3a" }}>- Retiro</button>
      </div>
    </div>
  );
}
function DebtRow({ d, onUpdate, onDelete }) {
  return (
    <div className="p-3 rounded-2xl" style={{ background: "var(--bg)" }}>
      <div className="flex items-center gap-2 mb-2">
        <TextInput value={d.name} onChange={e => onUpdate({ name: e.target.value })} className="flex-1" />
        <button onClick={onDelete} className="chc-iconbtn"><Trash2 size={14} /></button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <TextInput type="number" value={d.monthlyPayment} onChange={e => onUpdate({ monthlyPayment: Number(e.target.value) })} placeholder="Pago mensual" />
        <TextInput type="number" value={d.balance} onChange={e => onUpdate({ balance: Number(e.target.value) })} placeholder="Saldo pendiente" />
      </div>
    </div>
  );
}

/* ============================================================
   MODALS: INCOME / EXPENSE / PAYMENT / RECEIPT
============================================================ */
function IncomeModal({ state, onClose, ctx }) {
  const { addIncome, updateIncome, selectedYear, selectedMonth } = ctx;
  const editing = state.editing;
  const base = editing || state.prefill || { person: "Susan", concept: "", amount: "", date: `${selectedYear}-${pad2(selectedMonth)}-15`, quincena: 15, type: "Salario", note: "" };
  const [form, setForm] = useState(base);
  useEffect(() => { setForm(editing || state.prefill || { person: "Susan", concept: "", amount: "", date: `${selectedYear}-${pad2(selectedMonth)}-15`, quincena: 15, type: "Salario", note: "" }); }, [state.open, editing, state.prefill]);
  const [error, setError] = useState("");

  function save() {
    if (!form.amount || Number(form.amount) <= 0) { setError("Ingresa un monto válido."); return; }
    if (!form.person) { setError("Selecciona una persona."); return; }
    if (!form.quincena) { setError("Selecciona una quincena."); return; }
    const payload = { ...form, amount: Number(form.amount), quincena: Number(form.quincena), concept: form.concept || "Ingreso" };
    if (editing) updateIncome(editing.id, payload); else addIncome(payload);
    onClose();
  }

  return (
    <Modal open={state.open} onClose={onClose} title={editing ? "Editar ingreso" : "Nuevo ingreso"}>
      <Field label="Persona">
        <SelectInput value={form.person} onChange={e => setForm({ ...form, person: e.target.value })}>
          {INCOME_PERSONS.map(p => <option key={p} value={p}>{p}</option>)}
        </SelectInput>
      </Field>
      <Field label="Concepto">
        <TextInput value={form.concept} onChange={e => setForm({ ...form, concept: e.target.value })} placeholder="Ej: Salario, Bono, Reembolso" />
      </Field>
      <Field label="Monto">
        <TextInput type="number" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} placeholder="0" autoFocus />
      </Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Quincena">
          <SelectInput value={form.quincena} onChange={e => setForm({ ...form, quincena: Number(e.target.value) })}>
            <option value={15}>15</option><option value={30}>30</option>
          </SelectInput>
        </Field>
        <Field label="Fecha">
          <TextInput type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} />
        </Field>
      </div>
      <Field label="Tipo">
        <SelectInput value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
          {INCOME_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </SelectInput>
      </Field>
      <Field label="Observación (opcional)">
        <TextInput value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} />
      </Field>
      {error ? <p className="text-sm mb-2" style={{ color: "var(--rose)" }}>{error}</p> : null}
      <div className="flex gap-2">
        <BigButton variant="ghost" className="flex-1" onClick={onClose}>Cancelar</BigButton>
        <BigButton className="flex-1" onClick={save}>{editing ? "Guardar cambios" : "Registrar ingreso"}</BigButton>
      </div>
    </Modal>
  );
}

function ExpenseModal({ state, onClose, ctx }) {
  const { addExpense, updateExpense, data, addRecurringTemplate, updateRecurringTemplate } = ctx;
  const editing = state.editing;
  const emptyForm = { name: "", categoryId: data.categories[0]?.id, budgeted: "", actual: "", responsible: "Ambos", quincena: 15, dueDate: "", note: "", recurring: false, status: "Pendiente" };
  const [form, setForm] = useState(editing ? { ...editing, budgeted: editing.budgeted ?? "", actual: editing.actual ?? "" } : emptyForm);
  useEffect(() => { setForm(editing ? { ...editing, budgeted: editing.budgeted ?? "", actual: editing.actual ?? "" } : emptyForm); }, [state.open, editing]);
  const [error, setError] = useState("");

  function save() {
    if (!form.name.trim()) { setError("Ingresa un nombre para el gasto."); return; }
    if (!form.budgeted || Number(form.budgeted) < 0) { setError("Ingresa un monto presupuestado válido."); return; }
    if (!form.quincena) { setError("Selecciona una quincena."); return; }

    let templateId = editing?.templateId || null;
    if (form.recurring && !templateId) {
      const dueDay = form.dueDate ? Number(form.dueDate.slice(8, 10)) : null;
      const newTemplate = { id: uid(), name: form.name, categoryId: form.categoryId, budgeted: Number(form.budgeted), responsible: form.responsible, quincena: Number(form.quincena), dueDay, active: true };
      addRecurringTemplate(newTemplate);
      templateId = newTemplate.id;
    } else if (!form.recurring && templateId) {
      updateRecurringTemplate(templateId, { active: false });
      templateId = null;
    } else if (form.recurring && templateId) {
      updateRecurringTemplate(templateId, { name: form.name, categoryId: form.categoryId, budgeted: Number(form.budgeted), responsible: form.responsible, quincena: Number(form.quincena) });
    }

    const payload = {
      name: form.name.trim(), categoryId: form.categoryId, budgeted: Number(form.budgeted),
      actual: form.actual !== "" ? Number(form.actual) : null, responsible: form.responsible,
      quincena: Number(form.quincena), dueDate: form.dueDate || null, note: form.note || "",
      recurring: form.recurring, templateId,
    };
    if (editing) updateExpense(editing.id, payload); else addExpense(payload);
    onClose();
  }

  return (
    <Modal open={state.open} onClose={onClose} title={editing ? "Editar gasto" : "Nuevo gasto"} wide>
      <Field label="Nombre"><TextInput value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} autoFocus /></Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Categoría">
          <SelectInput value={form.categoryId} onChange={e => setForm({ ...form, categoryId: e.target.value })}>
            {data.categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </SelectInput>
        </Field>
        <Field label="Responsable">
          <SelectInput value={form.responsible} onChange={e => setForm({ ...form, responsible: e.target.value })}>
            {RESPONSIBLES.map(r => <option key={r} value={r}>{r}</option>)}
          </SelectInput>
        </Field>
        <Field label="Monto presupuestado"><TextInput type="number" value={form.budgeted} onChange={e => setForm({ ...form, budgeted: e.target.value })} /></Field>
        <Field label="Monto real (si ya pagaste)"><TextInput type="number" value={form.actual} onChange={e => setForm({ ...form, actual: e.target.value })} /></Field>
        <Field label="Quincena">
          <SelectInput value={form.quincena} onChange={e => setForm({ ...form, quincena: Number(e.target.value) })}>
            <option value={15}>15</option><option value={30}>30</option>
          </SelectInput>
        </Field>
        <Field label="Fecha de vencimiento"><TextInput type="date" value={form.dueDate || ""} onChange={e => setForm({ ...form, dueDate: e.target.value })} /></Field>
      </div>
      <label className="flex items-center gap-2 mb-3 text-sm font-medium">
        <input type="checkbox" checked={form.recurring} onChange={e => setForm({ ...form, recurring: e.target.checked })} />
        Repetir todos los meses
      </label>
      <Field label="Observación (opcional)"><TextInput value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} /></Field>
      {editing ? <ReceiptSection expenseId={editing.id} ctx={ctx} /> : <p className="text-xs mb-3" style={{ color: "var(--muted)" }}>Podrás adjuntar el comprobante después de guardar el gasto.</p>}
      {error ? <p className="text-sm mb-2" style={{ color: "var(--rose)" }}>{error}</p> : null}
      <div className="flex gap-2">
        <BigButton variant="ghost" className="flex-1" onClick={onClose}>Cancelar</BigButton>
        <BigButton className="flex-1" onClick={save}>{editing ? "Guardar cambios" : "Agregar gasto"}</BigButton>
      </div>
    </Modal>
  );
}

function ReceiptSection({ expenseId, ctx }) {
  const { attachReceipt, removeReceipt, viewReceipt } = ctx;
  const galleryRef = useRef(null);
  const cameraRef = useRef(null);
  const hasReceipt = ctx.month.expenses.find(e => e.id === expenseId)?.hasReceipt;
  return (
    <div className="mb-4 p-3 rounded-2xl" style={{ background: "var(--bg)" }}>
      <p className="text-sm font-semibold mb-2">Comprobante</p>
      {hasReceipt ? (
        <div className="flex gap-2">
          <BigButton variant="ghost" className="flex-1" onClick={() => viewReceipt(expenseId)}><Paperclip size={14} className="inline -mt-0.5 mr-1" />Ver</BigButton>
          <BigButton variant="ghost" className="flex-1" onClick={() => galleryRef.current?.click()}>Reemplazar</BigButton>
          <BigButton variant="danger" onClick={() => removeReceipt(expenseId)}><Trash2 size={14} /></BigButton>
        </div>
      ) : (
        <div className="flex gap-2">
          <BigButton variant="ghost" className="flex-1" onClick={() => galleryRef.current?.click()}><ImageIcon size={14} className="inline -mt-0.5 mr-1" />Elegir foto</BigButton>
          <BigButton variant="ghost" className="flex-1" onClick={() => cameraRef.current?.click()}><Camera size={14} className="inline -mt-0.5 mr-1" />Tomar foto</BigButton>
        </div>
      )}
      <input ref={galleryRef} type="file" accept="image/jpeg,image/jpg,image/png,image/webp" className="hidden" onChange={e => { if (e.target.files[0]) attachReceipt(expenseId, e.target.files[0]); e.target.value = ""; }} />
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={e => { if (e.target.files[0]) attachReceipt(expenseId, e.target.files[0]); e.target.value = ""; }} />
    </div>
  );
}

function PaymentModal({ state, onClose, ctx }) {
  const e = state.expense;
  const { markPaid, data } = ctx;
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState("");
  useEffect(() => { if (e) { setAmount(e.budgeted); setDate(todayISO()); setNote(e.note || ""); } }, [e, state.open]);
  const galleryRef = useRef(null);
  if (!e) return null;
  const receiptRequired = data.settings.receiptsMode === "required";
  return (
    <Modal open={state.open} onClose={onClose} title="Registrar pago">
      <div className="mb-3">
        <p className="font-bold">{e.name}</p>
        <p className="text-sm" style={{ color: "var(--muted)" }}>Presupuestado: {formatCRC(e.budgeted)}</p>
      </div>
      <Field label="Monto pagado"><TextInput type="number" value={amount} onChange={ev => setAmount(ev.target.value)} autoFocus /></Field>
      <Field label="Fecha (opcional)"><TextInput type="date" value={date} onChange={ev => setDate(ev.target.value)} /></Field>
      <Field label="Nota (opcional)"><TextInput value={note} onChange={ev => setNote(ev.target.value)} /></Field>
      <ReceiptSection expenseId={e.id} ctx={ctx} />
      <input ref={galleryRef} className="hidden" />
      <div className="flex gap-2">
        <BigButton variant="ghost" className="flex-1" onClick={onClose}>Cancelar</BigButton>
        <BigButton
          className="flex-1"
          onClick={() => {
            const fresh = ctx.month.expenses.find(x => x.id === e.id);
            if (receiptRequired && !fresh?.hasReceipt) { alert("La configuración exige adjuntar un comprobante antes de marcar como pagado."); return; }
            markPaid(e.id, { actual: amount, paidDate: date, note });
            onClose();
          }}
        >
          Confirmar pago
        </BigButton>
      </div>
    </Modal>
  );
}

function ReceiptModal({ state, onClose, ctx }) {
  const { removeReceipt } = ctx;
  if (!state.open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(10,15,20,0.85)" }} onClick={onClose}>
      <div className="max-w-md w-full" onClick={e => e.stopPropagation()}>
        <img src={state.src} alt="Comprobante" className="w-full rounded-2xl mb-3" />
        <div className="flex gap-2">
          <BigButton variant="ghost" className="flex-1" onClick={onClose}>Cerrar</BigButton>
          <BigButton variant="danger" onClick={() => removeReceipt(state.expenseId)}><Trash2 size={14} className="inline -mt-0.5 mr-1" />Eliminar</BigButton>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   GLOBAL STYLES
============================================================ */
function ChcStyle() {
  return (
    <style>{`
      :root {
        --petrol: #123C4A;
        --petrol-light: #1F5C6E;
        --teal-accent: #2E8B8B;
        --ink: #1E2530;
        --muted: #6B7686;
        --bg: #F5F7F8;
        --card: #FFFFFF;
        --border: #E7EAEE;
        --green: #4CAF7D;
        --green-bg: #E7F6EE;
        --amber: #E2A63B;
        --amber-bg: #FDF3E1;
        --rose: #E36767;
        --rose-bg: #FBE9E9;
      }
      .chc-app { background: var(--bg); color: var(--ink); font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; min-height: 100vh; }
      .chc-num { font-variant-numeric: tabular-nums; }
      .chc-card { background: var(--card); border-radius: 20px; border: 1px solid var(--border); box-shadow: 0 1px 2px rgba(18,60,74,0.05); }
      .chc-hero { background: linear-gradient(135deg, var(--petrol) 0%, var(--teal-accent) 100%); color: #fff; border-radius: 24px; }
      .chc-btn { border-radius: 14px; font-weight: 700; padding: 12px 18px; font-size: 14px; transition: transform .05s ease; }
      .chc-btn:active { transform: scale(0.98); }
      .chc-btn:disabled { opacity: 0.45; }
      .chc-btn-primary { background: var(--petrol); color: #fff; }
      .chc-btn-ghost { background: #fff; border: 1px solid var(--border); color: var(--ink); }
      .chc-btn-soft { background: var(--bg); color: var(--ink); border: 1px solid var(--border); }
      .chc-btn-danger { background: var(--rose); color: #fff; }
      .chc-pill { border-radius: 999px; padding: 3px 10px; font-size: 11px; font-weight: 700; display: inline-flex; align-items: center; }
      .chc-pill-green { background: var(--green-bg); color: #1f7a4d; }
      .chc-pill-amber { background: var(--amber-bg); color: #95610f; }
      .chc-pill-rose { background: var(--rose-bg); color: #b23a3a; }
      .chc-pill-neutral { background: var(--bg); color: var(--muted); }
      .chc-input { width: 100%; border: 1px solid var(--border); border-radius: 12px; padding: 10px 12px; font-size: 16px; background: #fff; color: var(--ink); outline: none; }
      .chc-input:focus { border-color: var(--teal-accent); }
      .chc-select-inline { width: auto; padding: 8px 10px; font-weight: 700; font-size: 14px; color: var(--petrol); }
      .chc-iconbtn { padding: 8px; border-radius: 12px; background: var(--bg); border: 1px solid var(--border); display: inline-flex; align-items: center; justify-content: center; }
      .chc-quickbtn { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; font-weight: 700; padding: 7px 10px; border-radius: 12px; }
      .chc-filter-chip { font-size: 12.5px; font-weight: 600; padding: 7px 12px; border-radius: 999px; }
      .chc-details { background: var(--card); border: 1px solid var(--border); border-radius: 18px; padding: 14px; }
      .chc-summary { font-weight: 700; color: var(--petrol); cursor: pointer; list-style: none; display: flex; align-items: center; justify-content: space-between; }
      .chc-summary::-webkit-details-marker { display: none; }
      .chc-spinner { width: 32px; height: 32px; border-radius: 999px; border: 3px solid var(--border); border-top-color: var(--petrol); animation: chc-spin 0.8s linear infinite; }
      @keyframes chc-spin { to { transform: rotate(360deg); } }
    `}</style>
  );
}
