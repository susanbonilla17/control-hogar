// Contraseña única y compartida para entrar a Control Hogar.
// Cámbiala por la que ustedes quieran antes de publicar la app.
export const APP_PASSWORD = "Home2026";
