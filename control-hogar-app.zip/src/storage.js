import { initializeApp, getApps } from "firebase/app";
import {
  getFirestore, doc, getDoc, setDoc, deleteDoc,
  collection, query, where, getDocs, onSnapshot,
} from "firebase/firestore";
import { firebaseConfig } from "./firebaseConfig";

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
export const db = getFirestore(app);

// All structured data + receipt images live in one Firestore collection "kv",
// one document per key, so this module mirrors the same tiny interface the
// app was originally written against (get/set/delete/list-by-prefix).
const KV = "kv";

export function subscribeKey(key, callback) {
  return onSnapshot(
    doc(db, KV, key),
    (snap) => callback(snap.exists() ? snap.data().value : null),
    () => callback(null)
  );
}

export async function storageGet(key) {
  try {
    const snap = await getDoc(doc(db, KV, key));
    return snap.exists() ? snap.data().value : null;
  } catch (e) { return null; }
}

export async function storageSet(key, value) {
  try { await setDoc(doc(db, KV, key), { key, value }); } catch (e) { /* ignore */ }
}

export async function storageDelete(key) {
  try { await deleteDoc(doc(db, KV, key)); } catch (e) { /* ignore */ }
}

export async function storageListPrefix(prefix) {
  try {
    const q = query(collection(db, KV), where("key", ">=", prefix), where("key", "<", prefix + "\uf8ff"));
    const snaps = await getDocs(q);
    return snaps.docs.map((d) => d.id);
  } catch (e) { return []; }
}
