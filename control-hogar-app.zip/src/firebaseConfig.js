// Pega aquí la configuración de TU proyecto de Firebase.
// La obtienes en: Firebase Console -> Configuración del proyecto -> Tus apps -> app Web.
// Es gratis y toma unos minutos. Ver README.md para la guía paso a paso.

export const firebaseConfig = {
  apiKey: "AIzaSyB9Wx7p2SvoXdDZMFcON9qjZ3ofa6v0-Ig",
  authDomain: "control-hogar-88755.firebaseapp.com",
  projectId: "control-hogar-88755",
  storageBucket: "control-hogar-88755.firebasestorage.app",
  messagingSenderId: "871329826773",
  appId: "1:871329826773:web:37042ab4993c0009861f5c",
};
