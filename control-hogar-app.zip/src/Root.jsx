import React, { useState } from "react";
import App from "./App";
import Login, { isAuthed } from "./Login";

export default function Root() {
  const [authed, setAuthed] = useState(isAuthed());
  if (!authed) return <Login onSuccess={() => setAuthed(true)} />;
  return <App />;
}
