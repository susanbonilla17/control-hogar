import React, { useState } from "react";
import { Lock } from "lucide-react";
import { APP_PASSWORD } from "./accessConfig";

const AUTH_KEY = "chc-auth-ok";

export function isAuthed() {
  try { return localStorage.getItem(AUTH_KEY) === "1"; } catch (e) { return false; }
}

export default function Login({ onSuccess }) {
  const [value, setValue] = useState("");
  const [error, setError] = useState("");

  function submit(e) {
    e.preventDefault();
    if (value === APP_PASSWORD) {
      try { localStorage.setItem(AUTH_KEY, "1"); } catch (e) { /* ignore */ }
      onSuccess();
    } else {
      setError("Contraseña incorrecta. Intenta de nuevo.");
    }
  }

  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
      background: "#F5F7F8", fontFamily: "ui-sans-serif, system-ui, sans-serif", padding: 16,
    }}>
      <form onSubmit={submit} style={{
        background: "#fff", borderRadius: 24, padding: 28, width: "100%", maxWidth: 360,
        border: "1px solid #E7EAEE", boxShadow: "0 1px 2px rgba(18,60,74,0.06)",
      }}>
        <div style={{
          width: 48, height: 48, borderRadius: 16, background: "#123C4A",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16,
        }}>
          <Lock color="#fff" size={22} />
        </div>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: "#123C4A", marginBottom: 4 }}>Control Hogar</h1>
        <p style={{ fontSize: 13, color: "#6B7686", marginBottom: 16 }}>Ingresa la contraseña compartida para continuar.</p>
        <input
          type="password"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Contraseña"
          autoFocus
          style={{
            width: "100%", padding: "12px 14px", borderRadius: 12, border: "1px solid #E7EAEE",
            fontSize: 16, marginBottom: 10, outline: "none",
          }}
        />
        {error ? <p style={{ color: "#E36767", fontSize: 13, marginBottom: 10 }}>{error}</p> : null}
        <button type="submit" style={{
          width: "100%", padding: "12px 16px", borderRadius: 14, border: "none",
          background: "#123C4A", color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer",
        }}>
          Entrar
        </button>
      </form>
    </div>
  );
}
