# Control Hogar — guía para publicarla

Esta es la versión de Control Hogar lista para vivir fuera de Claude, en su
propia dirección web, con:

- **Un solo usuario y contraseña compartida** (pantalla de acceso simple).
- **Datos globales**: lo que Susan o Ale registre se sincroniza para ambos,
  en tiempo real, en cualquier teléfono o computadora.

Para lograr el "dato compartido entre dispositivos" se usa **Firebase
Firestore**, un servicio gratuito de Google (su capa gratuita alcanza de
sobra para un hogar). Sin esto, cada teléfono guardaría su propia copia por
separado.

Hay dos pasos: **(1) conectar la base de datos gratis** y **(2) publicar la
app**. Tarda unos 15–20 minutos la primera vez.

---

## Paso 1 — Crear la base de datos gratis (Firebase)

1. Entra a **https://console.firebase.google.com** e inicia sesión con una
   cuenta de Google.
2. Clic en **"Agregar proyecto"** (o "Crear un proyecto"). Ponle un nombre,
   por ejemplo `control-hogar`. Puedes desactivar Google Analytics, no hace
   falta.
3. Dentro del proyecto, en el menú lateral: **Build → Firestore Database**.
4. Clic en **"Crear base de datos"**.
   - Elige la ubicación más cercana (por ejemplo una en EE. UU. o la que te
     sugiera por defecto).
   - Selecciona **"Iniciar en modo de prueba"** (test mode). Esto permite
     leer/escribir sin configuración extra — como la app ya está protegida
     por la contraseña compartida, es suficiente para uso familiar.
5. Ve a **Configuración del proyecto** (ícono de engranaje, arriba a la
   izquierda) → pestaña **General** → baja hasta "Tus apps" → clic en el
   ícono **`</>`** (Web) para agregar una app web.
   - Ponle un apodo, por ejemplo `control-hogar-web`. No necesitas Firebase
     Hosting.
6. Te va a mostrar un bloque de código con algo llamado `firebaseConfig`.
   Copia esos valores (apiKey, authDomain, projectId, etc.) y pégalos en el
   archivo **`src/firebaseConfig.js`** de este proyecto, reemplazando los
   textos de ejemplo.

> Nota: el modo de prueba de Firestore expira sus reglas de acceso abierto
> a los 30 días. Cuando llegue ese aviso en la consola de Firebase, entra a
> **Firestore Database → Reglas** y reemplaza el contenido por:
>
> ```
> rules_version = '2';
> service cloud.firestore {
>   match /databases/{database}/documents {
>     match /{document=**} {
>       allow read, write: if true;
>     }
>   }
> }
> ```
>
> Esto mantiene el acceso abierto indefinidamente (recuerda: la protección
> real la da la contraseña de la app, no Firestore).

## Paso 2 — Cambiar la contraseña compartida

Abre **`src/accessConfig.js`** y cambia el valor de `APP_PASSWORD` por la
contraseña que van a usar Susan y Ale.

---

## Paso 3 — Publicar la app

Elige el camino que te resulte más cómodo. Ambos son gratuitos.

### Opción A — Replit (todo desde el navegador, sin instalar nada)

1. Entra a **replit.com** e inicia sesión.
2. Crea un **"Repl"** nuevo → elige la plantilla **"Import from GitHub"** si
   subiste este proyecto a GitHub, o **"Node.js"/"Vite"** y luego arrastra
   o sube todos los archivos de esta carpeta dentro del Repl.
3. En la terminal integrada de Replit, ejecuta:
   ```
   npm install
   npm run build
   npm run preview -- --host
   ```
4. Replit te da una URL pública para el Repl (botón "Webview" o "Deploy").
   Para que quede fija y siempre disponible, usa el botón **"Deploy"** de
   Replit (Static/Autoscale) apuntando a la carpeta `dist` generada por
   `npm run build`.

### Opción B — Netlify

**Sin usar terminal (más simple):**
1. En tu computadora, necesitas Node.js instalado (https://nodejs.org).
2. Abre una terminal en esta carpeta y corre:
   ```
   npm install
   npm run build
   ```
   Esto crea una carpeta `dist/` con la app ya lista.
3. Entra a **app.netlify.com** → **"Add new site" → "Deploy manually"** →
   arrastra la carpeta `dist` a la zona indicada. Netlify te da un enlace
   público al instante (algo como `nombre-al-azar.netlify.app`).
4. Opcional: en "Site settings → Domain management" puedes personalizar el
   subdominio.

**Con GitHub (recomendado si van a seguir editando):**
1. Sube esta carpeta completa a un repositorio de GitHub.
2. En Netlify: **"Add new site" → "Import an existing project"** → conecta
   tu cuenta de GitHub y elige el repositorio.
3. Netlify detecta automáticamente `npm run build` y la carpeta `dist`
   (ya está configurado en `netlify.toml`). Clic en "Deploy".
4. Cada vez que subas un cambio a GitHub, Netlify vuelve a publicar solo.

---

## Instalar como app en el teléfono

Una vez publicada (con su URL de Netlify o Replit):

- **Android (Chrome)**: abre la URL → menú (⋮) → "Agregar a pantalla de
  inicio" o "Instalar app".
- **iPhone (Safari)**: abre la URL → botón compartir → "Agregar a pantalla
  de inicio".

Así queda con su propio ícono, sin la barra del navegador, como una app
normal — y sin la marca de Claude.

---

## ¿Qué se mantiene igual y qué cambia respecto a la versión en Claude?

- **Se mantiene**: todo el diseño, cálculos, comprobantes con foto,
  categorías, recurrentes, fondos, deudas, resumen mensual/anual,
  respaldo JSON/CSV.
- **Cambia**: en vez del guardado especial de Claude, ahora los datos
  viven en tu propio proyecto de Firebase (gratis, y de tu propiedad —
  nadie de Anthropic tiene acceso a esos datos).
- **Cambia**: hay una pantalla de contraseña compartida antes de entrar.
